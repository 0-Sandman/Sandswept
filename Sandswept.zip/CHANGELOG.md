# 0.6.0 Patch Notes
- Ranger
- - Added sound cue and overlay flash at Max Charge
- - Buffed Enflame Damage from 110% to 120%
- - Buffed Exhaust Damage from 8x140% to 8x160%
- - Buffed Exhaust Proc Coefficient from 0.4 to 0.5
- - Nerfed Full Heat Self Damage slightly
- - Made Full Heat increase base damage, scaling with time spent in it
- - Made Full Heat Self Damage unaffected by Eclipse 8
- - Made Release and Exhaust take priority over holding M1
- - Increased Exhaust Recoil
- - Scaled down base form crosshair (can't lower it right now because unity ! !)
- - Updated Overdrive description
- - Updated Tips section
- - Updated Skin Icon colors
- - Fixed Exhaust description
- - Fixed Heat Sink description
- Readme
- - Fixed wrong descriptions

# 0.5.0 Patch Notes
- Release
- Added 1 Survivor
- Added 1 Elite
- Added 10 Items
