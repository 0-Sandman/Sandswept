# 0.0.1 Patch Notes

- Release
- Added 1 Survivor
- Added 1 Elite
- Added 10 Items
