# 0.5.0 Patch Notes

- Release
- Added 1 Survivor
- Added 1 Elite
- Added 10 Items
