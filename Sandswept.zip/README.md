# <a href="https://discord.gg/zcQnUUPdpW"><img src="https://i.postimg.cc/Qxwf7yLw/booook-1.gif" width="1100"/></a>
### <img src="https://i.postimg.cc/T3FJSHfy/sandsw-ept-Icon.png" width="32"/> Sandswept is a content expansion mod that aims to add a variety of content including:
- 2 Survivors
- 4 Enemies
- 2 Elites
- 4 Interactables
- 21 Items

### Feedback? Join the discord: (discord.gg/zcQnUUPdpW)

# Content

![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/B65DP2b7/RangerUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/D00xQ7DX/VOLTUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/g2cPkVQ0/EnemyUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/X7kbbH2h/EliteUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/htCRJJR1/Interactable-UI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/W35W2yFN/ItemUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)

# Credits

### Support us on KOFI! https://linktr.ee/SandsweptTeam

- Code: HIFU, pseudopulse, Sandman, prod, dgosling
- Models: Smxrez, Sandman, GEMO, Bog, pseudopulse, prod, HIFU
- Animations: IcieTea, unmatchedpowerofthesun, Bog
- VFX: HIFU, Sandman, prod
- Skill Icons: prod, HIFU
- Additional Help: swuff★, DuhDoesNothing
- Concept Art: yorikobear, IcieTea, Sandman, Shepd
- Playtesters: .score, BubbleTanks, Interlink, JimKas, Fyrebw42, James, Jaysian, Phreel, swuff★, Sage, Saucy Wench, Soylar, TheViralMelon, Tizi, Yarrowyeen, Zynthesizer
- Lore: TheViralMelon, Zynthesizer

<details><summary></summary>

<img src="https://i.postimg.cc/7Z94LTYD/true50.png"/>
<br>
<img src="https://i.postimg.cc/qRhHQbcM/rework-Idea4.png"/>
<br>
<img src="https://i.postimg.cc/T3fGGcxC/true51.png"/>
<br>
<img src="https://i.postimg.cc/3wbHX5vc/WHATT.png"/>
<br>
<img src="https://i.postimg.cc/Jn3mqFdR/imageeee.png"/>
<br>
<img src="https://i.postimg.cc/brNXRwtR/brainrot.png"/>
<br>
<img src="https://i.postimg.cc/tCwfs52k/true.png"/>
<br>
<img src="https://i.postimg.cc/WpfYy8LV/eaea.png"/>
<br>
<img src="https://i.postimg.cc/bJfSrKtP/misinformation.png"/>
<br>
<img src="https://i.postimg.cc/9Xb0rQKd/sandsw-eptdevelopmentteam.png"/>
<br>
<img src="https://i.postimg.cc/FKfyBPPS/megarex.png"/>
<br>
Do not click on her icon too many times.

</details>
