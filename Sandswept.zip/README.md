# <a href="https://discord.gg/zcQnUUPdpW"><img src="https://i.postimg.cc/Qxwf7yLw/booook-1.gif" width="1100"/></a>
### <img src="https://i.postimg.cc/T3FJSHfy/sandsw-ept-Icon.png" width="32"/> Sandswept is a content expansion mod that aims to add a variety of content including:
- 2 Survivors
- 4 Enemies
- 2 Elites
- 5 Interactables
- 27 Items

### Feedback? Join the discord: (discord.gg/zcQnUUPdpW)

# Content

![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/C17yD5bF/RangerUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/mDBftCzX/VOLTUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/1X0K4VFH/EnemyUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/X7kbbH2h/EliteUI.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/pdHm53ZG/Interactable-UI-2.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)
![](https://i.postimg.cc/QxK5mdjC/Item-UI-top.png)
![](https://i.postimg.cc/XvnbjLL5/Item-UI-bottom.png)
![](https://i.postimg.cc/4dQSXLCW/Divider-UI.png)

# Credits

### Support us on KOFI! https://linktr.ee/SandsweptTeam

- Code: HIFU, Pseudopulse
  - With small contributions from: Prod, Sandman, dgosling
- Models: Smxrez, Synodii, Pseudopulse, HIFU, Sandman
  - Formerly: GEMO
  - With small contributions from: Prod
- Animations: Snonepe, Pseudopulse, Synodii
  - Formerly: IcieTea, Bog, Unmatchedpowerofthesun
- VFX: HIFU, Pseudopulse
  - With small former contributions from: Sandman, Prod
- SFX: HIFU, Pseudopulse
- Skill Icons: Prod
- Concepts and art: yorikobear, IcieTea, Sandman, Shepd
  - With small contributions from: Swuff, DuhDoesNothing, Pseudopulse, Smxrez, Synodii, HIFU
- Lore: TheViralMelon, Zynthesizer
- Playtesters: .Score, BubbleTanks, Interlink, JimKas, Fyrebw42, James, Jaysian, Phreel, Swuff, Sage, Saucy Wench, Soylar, TheViralMelon, Tizi, Yarrowyeen, Zynthesizer, All public playtesters

<details><summary></summary>

<img src="https://i.postimg.cc/7Z94LTYD/true50.png"/>
<br>
<img src="https://i.postimg.cc/qRhHQbcM/rework-Idea4.png"/>
<br>
<img src="https://i.postimg.cc/T3fGGcxC/true51.png"/>
<br>
<img src="https://i.postimg.cc/3wbHX5vc/WHATT.png"/>
<br>
<img src="https://i.postimg.cc/Jn3mqFdR/imageeee.png"/>
<br>
<img src="https://i.postimg.cc/brNXRwtR/brainrot.png"/>
<br>
<img src="https://i.postimg.cc/tCwfs52k/true.png"/>
<br>
<img src="https://i.postimg.cc/WpfYy8LV/eaea.png"/>
<br>
<img src="https://i.postimg.cc/bJfSrKtP/misinformation.png"/>
<br>
<img src="https://i.postimg.cc/9Xb0rQKd/sandsw-eptdevelopmentteam.png"/>
<br>
<img src="https://i.postimg.cc/FKfyBPPS/megarex.png"/>
<br>
<img src="https://i.postimg.cc/LXD1y01N/image.png"/>
<br>
<img src="https://i.postimg.cc/d3XDpMtn/image.png"/>
<br>
<img src="https://i.ibb.co/zH6yFzRp/image.png"/>
<br>
<img src="https://i.ibb.co/V0znKJLY/image.png"/>
<br>
<img src="https://i.postimg.cc/h4MJskcC/image-psd(148).png"/>
<br>

</details>
